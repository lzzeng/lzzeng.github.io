# coding:utf-8

import sys
import time
from itertools import islice



def read_in_chunks(file_path, n):
    with open(file_path, encoding="utf-8") as fh:
        while True:
            lines = list(islice(fh, n))
            if lines:
                yield lines
            else:
                break


if __name__ == '__main__':
    logfile = "./my.log"
    ts = 0.1
    nl = 3
    try:
      logfile = sys.argv[1] or logfile
      ts = float(sys.argv[2]) or ts
      nl = int(sys.argv[3]) or nl
    except:
      pass
    
    for lines in read_in_chunks(logfile, nl):
        print("sleep ...")
        time.sleep(float(ts))
        print("sleep 222...")
        for line in lines:
            print(line.rstrip())

