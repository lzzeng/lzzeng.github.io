#!/bin/sh


mypath=$(cd `dirname $0`; pwd)
replay_dir=$1
replay_dir=${replay_dir:=.}
if [ ! -d "$replay_dir" ]; then
  replay_dir=.
fi

let n=0

cd $replay_dir
ls *.his |while read line
do
  let n=n+1
  echo $n: $line
done

### input
while true
do
echo ""
read -p "Select a file to replay: " nSel
if [ -z "$nSel" ]; then
  nSel=1
fi

ck_1=$(echo "$nSel" |grep '^\s*[0-9]\+\s*$')
# ck_2=$(echo "$nSel" |grep '^\s*[0-9]\+\s*p\s*$')
ck_2=$(echo "$nSel" |grep '^\s*[0-9]\+\s*p.*$')
if [ -n "$ck_2" ]; then
  # nSel=$(echo "$nSel" |sed 's/ //g;s/p//')
  nSel=$(echo "$nSel" |sed 's/^\s*\([0-9]\+\)\s*p.*$/\1/')
fi

#echo ck_1: $ck_1
#echo ck_2: $ck_2
#echo nSel: $nSel
if [ -n "$ck_1" ] || [ -n "$ck_2" ]; then
  break
fi
done
#echo OK
t_para=`echo "$ck_2" |sed 's/^.*p//'`

### get input
sel=`ls *.his |sed -n "$nSel"p |sed 's/.his$//'`
echo "Selected: <$sel>"

if [ -n "$ck_2" ]; then
  echo "Will replay by print-log.py <> $t_para ..."
  python $mypath/print-log.py "${sel}.his" $t_para
  exit 0
fi

if [ -f "${sel}.time" ]; then
  echo ""
  # scriptreplay ${sel}.time ${sel}.his
  perl $mypath/scriptreplay.pl ${sel}.time ${sel}.his
elif [ -f "${sel}.his" ]; then
  echo "No time file, will replay by print-log.py <> $t_para ..."
  python $mypath/print-log.py "${sel}.his" $t_para
else
  echo "Replay file not found"
fi

